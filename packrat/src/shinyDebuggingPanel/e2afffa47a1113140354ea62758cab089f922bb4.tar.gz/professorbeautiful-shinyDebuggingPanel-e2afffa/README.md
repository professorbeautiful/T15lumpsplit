# shinyDebuggingPanel
shinyDebuggingPanel R package. You can include this panel in any shiny project.

To learn how, run:

help('makeDebuggingPanelOutput', package='shinyDebuggingPanel')

2018-05-05
Cosmetic improvements.
